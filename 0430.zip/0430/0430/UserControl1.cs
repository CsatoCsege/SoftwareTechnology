﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _0430
{
    public partial class UserControl1 : UserControl
    {
        Models.StudiesContext context = new();



        public UserControl1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void UserControl1_Load(object sender, EventArgs e)
        {
            //var instructors = from x in context.Instructors select x;
            //dataGridView1.DataSource = instructors.ToList();
            //dataGridView1.DataSource = context.Instructors.ToList();
            var instructors = from x in context.Instructors 
                              select new {
                                FullFullName = (x.Salutation + " " + x.Name).Trim().ToUpper(),
                                Status = x.StatusFkNavigation.Name,
                                Employment = x.EmployementFkNavigation.Name
                              };
            dataGridView1.DataSource = instructors.ToList();

        }
    }
}
