﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _0430
{
    public partial class UserControl2 : UserControl
    {
        Models.StudiesContext context = new Models.StudiesContext();
        public UserControl2()
        {
            InitializeComponent();
        }

        private void UserControl2_Load(object sender, EventArgs e)
        {
            instructorBindingSource.DataSource = context.Instructors.ToList();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            

        }

        private void instructorBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            if (instructorBindingSource.Current == null) return;
            Models.Instructor selectedInstructor = instructorBindingSource.Current as Models.Instructor;
            var lessonsOfTheSelectedInstructor = from x in context.Lessons
                                                 where x.InstructorFk == selectedInstructor.InstructorSk
                                                 select new
                                                 {
                                                     CourseName = x.CourseFkNavigation.Name,
                                                     Day = x.DayFkNavigation.Name,
                                                     TimeSlot = x.TimeFkNavigation.Name,
                                                     Room = x.RoomFkNavigation.Name
                                                 };
            dataGridView1.DataSource = lessonsOfTheSelectedInstructor.ToList();
        }
    }
}
